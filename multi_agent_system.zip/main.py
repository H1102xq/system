import operator
from typing import Annotated, List, TypedDict
from langchain_openai import ChatOpenAI
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage
from langgraph.graph import StateGraph, END

# 1. 定义系统状态（共享内存）
class AgentState(TypedDict):
    messages: Annotated[List[BaseMessage], operator.add]
    next_step: str
    task_completed: bool
    context: dict

# 2. 初始化模型 (请替换为你的 API Key)
llm = ChatOpenAI(model="gpt-4o", api_key="YOUR_OPENAI_API_KEY")

# --- Agent 定义 ---
def research_agent(state: AgentState):
    print("🔍 Research Agent is analyzing trends...")
    res = "当前热点：AI Agent 自动化运营，用户关注点在‘低成本’和‘高效率’。"
    return {"messages": [AIMessage(content=f"Research Result: {res}")], "next_step": "content_creator"}

def content_creator_agent(state: AgentState):
    print("✍️ Content Agent is writing copy...")
    last_msg = state['messages'][-1].content
    copy = f"基于{last_msg}创作的文案：【告别加班！用AI Agent实现运营自动化！】"
    return {"messages": [AIMessage(content=f"Created Copy: {copy}")], "next_step": "operator"}

def operator_agent(state: AgentState):
    print("🚀 Operator Agent is publishing...")
    feedback = "发布成功。初步数据：点击率 5%，用户反馈：希望看到具体代码实现。"
    return {"messages": [AIMessage(content=f"Operation Feedback: {feedback}")], "next_step": "manager"}

def manager_agent(state: AgentState):
    print("⚙️ Manager Agent is evaluating...")
    last_msg = state['messages'][-1].content
    if "希望看到具体代码" in last_msg:
        return {"next_step": "research_agent", "task_completed": False}
    return {"next_step": "end", "task_completed": True}

# 3. 构建工作流图
workflow = StateGraph(AgentState)
workflow.add_node("research_agent", research_agent)
workflow.add_node("content_creator", content_creator_agent)
workflow.add_node("operator", operator_agent)
workflow.add_node("manager", manager_agent)

workflow.set_entry_point("research_agent")
workflow.add_edge("research_agent", "content_creator")
workflow.add_edge("content_creator", "operator")
workflow.add_edge("operator", "manager")
workflow.add_conditional_edges("manager", lambda x: x["next_step"], {"research_agent": "research_agent", "end": END})

app = workflow.compile()

if __name__ == "__main__":
    inputs = {"messages": [HumanMessage(content="启动自动化运营流程：推广AI Agent产品")], "next_step": "", "task_completed": False, "context": {}}
    for output in app.stream(inputs):
        print(output)
