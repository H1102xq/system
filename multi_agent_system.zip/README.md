# 多Agent协同运营自动化系统
## 安装步骤
1. 安装依赖: `pip install -r requirements.txt`
2. 在 `main.py` 中填写你的 `api_key`。
3. 运行系统: `python main.py`

## 系统架构
- Research Agent -> Content Agent -> Operator Agent -> Manager Agent (Loop)
